<?php
class ApiKey {
    public function check() {
        // Añadir cabeceras CORS aquí
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With, API-Key");

        $CI =& get_instance();

        // Si es una solicitud OPTIONS, detener aquí.
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            // Envía una respuesta de éxito y detén la ejecución
            $CI->output
                ->set_status_header(200)
                ->_display();
            exit;
        }

        $apiKey = $CI->input->get_request_header('API-Key');

        if (!$apiKey || $apiKey !== '1954952eff1c76fbe2953b157502754fdbdcaffa') {
            // Respuesta si la API Key es inválida
            $CI->output
                ->set_content_type('application/json')
                ->set_status_header(401) // No autorizado
                ->set_output(json_encode(array('error' => 'API Key no válida')))
                ->_display();
            exit;
        }
    }
}
