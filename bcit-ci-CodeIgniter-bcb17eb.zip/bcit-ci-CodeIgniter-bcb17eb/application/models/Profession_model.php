<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Profession_model extends CI_Model {

    public function __construct() 
    {
        parent::__construct();
        $this->load->database();
    }

    // Método para obtener los oficios visibles
    public function getVisibleProfessions() {
        $this->db->select('
            o.oficio_id,
            o.oficio_descripcion
        ',);
        $this->db->where('oficio_visible', 'SI');
        $this->db->from('mahico_oficios o');

        $query = $this->db->get();
        return $query->result_array();
    }

}