<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Technician_model extends CI_Model {

    public function __construct() 
    {
        parent::__construct();
        $this->load->database();
    }

    public function getTechnicianById($technician_id) 
    {
        $this->db->select('
            t.tecnico_id,
            t.tecnico_nombre, 
            t.tecnico_bloqueado, 
            t.tecnico_bloqueo_desde, 
            t.tecnico_bloqueo_hasta,
            t.tecnico_dni,
            t.tecnico_CIF,
            t.tecnico_telefono,
            t.tecnico_precioxaviso,
            t.tecnico_precioxaviso_climaygas,
            t.tecnico_saldo,
            p.provincia_nombre,
            po.poblacion_nombre,
            o.oficio_descripcion');
        $this->db->from('mahico_tecnicos as t');
        // Realiza una serie de JOIN para obtener datos de otras tablas relacionadas usando alias
        $this->db->join('mahico_provincias as p', 't.tecnico_provincia_id = p.provincia_id', 'left');
        $this->db->join('mahico_poblaciones as po', 't.tecnico_poblacion_id = po.poblacion_id', 'left');
        $this->db->join('mahico_oficios as o', 't.tecnico_oficio_id = o.oficio_id', 'left');
        $this->db->where('t.tecnico_id', $technician_id);
        $query = $this->db->get();
    
        return $query->result_array(); 
    }
    
    public function getInvoicesById($technician_id) 
    {
        $this->db->select('
            f.factura_id,
            f.factura_empresa_id, 
            f.factura_tecnico_id, 
            f.factura_orden, 
            f.factura_fecha, 
            f.factura_concepto, 
            f.factura_base_imponible, 
            f.factura_tipo_iva, 
            f.factura_iva, 
            f.factura_total, 
            f.factura_pdf, 
            f.factura_excel, 
            f.factura_cobrada, 
            f.factura_documento_pago,
            f.factura_preliquidacion'
        );
        $this->db->from('mahico_facturas as f');
        $this->db->where('f.factura_tecnico_id', $technician_id);
        
        $query = $this->db->get();
        return $query->result_array();
    }

    public function createTechnician($data) {
        $this->db->insert('mahico_tecnicos', $data);
        return $this->db->insert_id();
    }

    // Método para obtener los técnicos disponibles por código postal y oficio
    public function getAvailableTechnicians($codigo_postal_cp, $oficio_id) 
    {
        $sql = "SELECT t.tecnico_nombre, t.tecnico_telefono, t.tecnico_id FROM mahico_tecnicos t 
                WHERE tecnico_bloqueado = 'NO' 
                AND t.tecnico_activo >= 0
                AND NOT ((t.tecnico_bloqueo_desde <= NOW() AND t.tecnico_bloqueo_desde <> '0000-00-00 00:00:00')
                AND (t.tecnico_bloqueo_hasta >= NOW() AND t.tecnico_bloqueo_hasta <> '0000-00-00 00:00:00'))
                AND ((t.tecnico_compra_avisos = 'SI' AND t.tecnico_saldo > 15) OR (t.tecnico_compra_avisos = 'NO'))
                AND tecnico_id IN (SELECT tecnico_id FROM mahico_tecnicos_oficios WHERE oficio_id IN (?))
                AND tecnico_id IN (SELECT tecnico_id FROM mahico_tecnicos_cps p, codigos_postales_geo g
                                   WHERE p.codigo_postal_id = g.codigo_postal_id AND g.codigo_postal_cp = ?)
                ORDER BY t.tecnico_prioridad DESC, t.tecnico_compra_avisos DESC, t.tecnico_plan_id";
        
        $query = $this->db->query($sql, array($oficio_id, $codigo_postal_cp));

        return $query->result_array();
    }

    public function login($username, $password)
    {
        $this->db->where('tecnico_nombre', $username);
        $this->db->where('tecnico_password', $password);
        $query = $this->db->get('mahico_tecnicos');

        if ($query->num_rows() === 1) {
            return $query->row_array(); // Devuelve el técnico si las credenciales son correctas
        } else {
            return false; // Credenciales incorrectas o técnico no encontrado
        }
    }
}
    

?>