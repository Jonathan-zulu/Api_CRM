<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Technicians extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Technician_model');
        $this->load->helper('url');
        $this->load->library('form_validation');
        // Añadir cabeceras CORS
        // Añadir cabeceras CORS
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    }

    public function getTechnician()
    {
        $headers = $this->input->request_headers();
        $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

        if (!$token) {
            $this->response(['error' => 'Token no proporcionado o inválido'], 401); // Unauthorized
            return;
        }

        $this->load->library('JwtHandler');
        $validation = $this->jwthandler->validateToken($token);

        if (!$validation['valid']) {
            $this->response(['error' => 'Token no válido o expirado'], 401); // Unauthorized
            return;
        }

        $technician_id = $this->input->get('id');
        if (!$technician_id) {
            $this->response(['error' => 'No se proporcionó el ID del técnico'], 400); // Bad Request
            return;
        }

        // Consultar el modelo para obtener datos
        $technician = $this->Technician_model->getTechnicianById($technician_id);
        if ($technician) {
            // Si se encontró el técnico, enviar los datos
            $this->response($technician, 200); // OK
        } else {
            // Si no se encontró el técnico, enviar un mensaje de error
            $this->response(['error' => 'No se encontraron técnicos para el ID proporcionado'], 404); // Not Found
        }
    }

    public function getInvoice()
    {
        $headers = $this->input->request_headers();
        $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

        if (!$token) {
            $this->response(['error' => 'Token no proporcionado o inválido'], 401); // Unauthorized
            return;
        }

        $this->load->library('JwtHandler');

        $validation = $this->jwthandler->validateToken($token);

        if (!$validation['valid']) {
            $this->response(['error' => 'Token no válido o expirado'], 401); // Unauthorized
            return;
        }

        $technician_id = $this->input->get('id');

        if (!$technician_id) {
            $this->response(['error' => 'No se proporcionó el ID del técnico'], 400); // Bad Request
            return;
        }
        $technician = $this->Technician_model->getInvoicesById($technician_id);

        if($technician) {
            $this->response($technician, 200);
        } else {
            $this->response(array('error' => "Technicians invoice not found."), 404);
        }

    }

    // Método para obtener técnicos disponibles
    public function getTechniciansAvailable() 
    {
        // Obtener el código postal y el ID del oficio desde los parámetros de consulta de la URL
        $codigoPostal = $this->input->get('codigo_postal');
        $oficioId = $this->input->get('oficio_id');

        // Verificar si se proporcionaron el código postal y el ID del oficio
        if (!$codigoPostal || !$oficioId) {
            // Si no se proporcionan los datos necesarios, enviar un mensaje de error con el código de estado HTTP 400 (Bad Request)
            $this->output
                ->set_content_type('application/json')
                ->set_status_header(400)
                ->set_output(json_encode(['error' => 'Faltan datos necesarios para la consulta.']));
            return;
        }

        // Consultar el modelo para obtener técnicos disponibles
        $availableTechnicians = $this->Technician_model->getAvailableTechnicians($codigoPostal, $oficioId);

        // Verificar si se encontraron técnicos disponibles
        if (!empty($availableTechnicians)) {
            // Si se encontraron técnicos disponibles, enviar los datos en formato JSON con el código de estado HTTP 200 (OK)
            $this->output
                ->set_content_type('application/json')
                ->set_status_header(200)
                ->set_output(json_encode($availableTechnicians));
        } else {
            // Si no se encontraron técnicos disponibles, enviar un mensaje de error con el código de estado HTTP 404 (Not Found)
            $this->output
                ->set_content_type('application/json')
                ->set_status_header(404)
                ->set_output(json_encode(['message' => 'No se encontraron técnicos disponibles.']));
        }
    }


    public function addTechnician()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            // Manejar el caso en que el método no sea POST
            $this->response([
                'error' => 'Método no permitido'
            ], 405); // Método no permitido
            return;
        }
        $postData = json_decode($this->input->raw_input_stream, true);

        // Configurar reglas de validación para los datos del técnico
        $this->form_validation->set_data($postData);
        $this->form_validation->set_rules('tecnico_nombre', 'Nombre', 'required');
        $this->form_validation->set_rules('tecnico_email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('tecnico_password', 'Contraseña', 'required');
        $this->form_validation->set_rules('tecnico_telefono', 'Teléfono', 'required');
        $this->form_validation->set_rules('tecnico_CIF', 'CIF', 'required');
        $this->form_validation->set_rules('tecnico_provincia_id', 'ID de Provincia', 'required|integer');

        // Verificar si la validación de formularios es exitosa
        if ($this->form_validation->run() === FALSE) {
            // Si la validación de formularios falla, enviar un mensaje de error
            $this->response([
                'error' => $this->form_validation->error_array()
            ], 400); // Bad Request
            return;
        }

        // Agregar la fecha de alta del técnico
        $postData['tecnico_fecha_alta'] = date('Y-m-d H:i:s');

        // Insertar el técnico utilizando el modelo
        $insertId = $this->Technician_model->createTechnician($postData);

        // Verificar si el técnico se registró con éxito
        if ($insertId) {
            // Si el técnico se registró con éxito, enviar un mensaje de éxito
            $this->response([
                'message' => 'Técnico registrado exitosamente',
                'tecnico_id' => $insertId
            ], 201); // Created
        } else {
            // Si el técnico no se registró con éxito, enviar un mensaje de error
            $this->response([
                'error' => 'No se pudo registrar el técnico'
            ], 500); // Internal Server Error
        }
    }

    public function login()
    {
        $postData = json_decode($this->input->raw_input_stream, true);

        $username = $postData['tecnico_nombre'];
        $password = $postData['tecnico_password'];

        $technician = $this->Technician_model->login($username, $password);

        if ($technician) {
            $this->load->library('JwtHandler');
            $token = $this->jwthandler->generateToken(['tecnico_id' => $technician['tecnico_id']]);

            // Devuelve el token JWT y el ID del técnico
            $this->response([
                'message' => 'Login exitoso',
                'token' => $token,
                'technic_id' => $technician['tecnico_id']
            ], 200);
        } else {
            $this->response([
                'error' => 'Credenciales incorrectas o técnico no encontrado'
            ], 401); // Unauthorized
        }
    }

    private function response($data, $status = 200) 
    {
        $this->output
            ->set_content_type('application/json')
            ->set_status_header($status)
            ->set_output(json_encode($data));
    }

}
