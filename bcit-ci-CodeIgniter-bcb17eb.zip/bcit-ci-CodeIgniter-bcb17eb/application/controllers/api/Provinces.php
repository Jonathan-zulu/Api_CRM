<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Provinces extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Province_model');
        $this->load->helper('url');
        // Añadir cabeceras CORS
        // Añadir cabeceras CORS
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    }

    // Método para obtener todas las provincias
    public function index() {
        // Obtiene todas las provincias utilizando el método 'get_provinces' del modelo 'Province_model'
        $provinces = $this->Province_model->getProvinces();

        // Verifica si se encontraron provincias
        if (!empty($provinces)) {
            // Si se encontraron provincias, devuelve las provincias en formato JSON y establece el código de estado HTTP en 200 (OK)
            $this->output
                 ->set_content_type('application/json')
                 ->set_status_header(200) // HTTP Status Code: OK
                 ->set_output(json_encode($provinces));
        } else {
            // Si no se encontraron provincias, devuelve un mensaje de error y establece el código de estado HTTP en 404 (Not Found)
            $this->output
                 ->set_content_type('application/json')
                 ->set_status_header(404) // HTTP Status Code: Not Found
                 ->set_output(json_encode(['message' => 'No se encontraron provincias']));
        }
    }
}