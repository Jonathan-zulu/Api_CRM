<?php
class Professions extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Profession_model');
        $this->load->helper('url');
        // Añadir cabeceras CORS
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    }

    // Método para obtener los oficios visibles
    public function getProfessions() {
        // Obtener los oficios visibles consultando el modelo
        $professions = $this->Profession_model->getVisibleProfessions();

        // Verificar si se encontraron oficios visibles
        if (!empty($professions)) {
            // Si se encontraron oficios visibles, enviar los datos en formato JSON con el código de estado HTTP 200 (OK)
            $this->output
                 ->set_content_type('application/json')
                 ->set_status_header(200)
                 ->set_output(json_encode($professions));
        } else {
            // Si no se encontraron oficios visibles, enviar un mensaje de error con el código de estado HTTP 404 (Not Found)
            $this->output
                 ->set_content_type('application/json')
                 ->set_status_header(404)
                 ->set_output(json_encode(['status' => FALSE, 'message' => 'No se encontraron oficios visibles']));
        }
    }
}